#include <iostream>
using namespace std;

int main()
{
	cout << "Hello World" << endl;
	cout << "Lol" << endl;
	return 0;
}
